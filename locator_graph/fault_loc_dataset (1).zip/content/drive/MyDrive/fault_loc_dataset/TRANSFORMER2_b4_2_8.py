
# Define the model
model = Sequential()
model.add(Conv2D(128))
model.add(ZeroPadding2D(1))
model.add(MaxPooling2D(1))
model.add(LayerNormalization())
model.add(Dense(128, relu))
model.add(MultiHeadAttention(None, None))
model.add(LayerNormalization())
model.add(Dense(1024))
model.add(Dense(2048))
model.add(Dense(128))
model.add(ResidualCon())
model.add(Dropout(0.77))
model.add(Dense(128))
model.add(Dense(100, activation='softmax'))

