
# Define the model
model = Sequential()
model.add(Embedding(64))
model.add(LayerNormalization())
model.add(Dense(64, relu))
model.add(MultiHeadAttention(None, None))
model.add(LayerNormalization())
model.add(Dense(1024))
model.add(Dense(2048))
model.add(Dense(64))
model.add(ResidualCon())
model.add(Dropout(0.62))
model.add(Dense(64))
model.add(Dense(100, activation='softmax'))

