
# Define the model
model = Sequential()
model.add(LayerNormalization())
model.add(Dense(32))
model.add(LayerNormalization())
model.add(Dense(32, relu))
model.add(MultiHeadAttention(None, None))
model.add(LayerNormalization())
model.add(Dense(1024))
model.add(Dense(2048))
model.add(Dense(32))
model.add(ResidualCon())
model.add(Dropout(0.0))
model.add(Dense(32))
model.add(Dense(100, activation='softmax'))

