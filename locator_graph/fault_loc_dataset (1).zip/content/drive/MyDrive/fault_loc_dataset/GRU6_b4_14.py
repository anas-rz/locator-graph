
model = Sequential()
model.add(GRU(256, recurrent_dropout=0.6, return_sequences=True))
model.add(Dense(len(sigma), activation='softmax'))
model.summary()
