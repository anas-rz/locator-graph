
model = Sequential()
model.add(GRU(32, return_sequences=True))
model.add(Dense(len(sigma), activation='softmax'))
model.summary()
