
# Create a Sequential model
model = Sequential()

model.add(layers.SimpleRNN(32, 
                        return_sequences=True))
model.add(layers.SimpleRNN(32, activation=softmax, recurrent_dropout=0.0, return_sequences=True))
model.add(layers.SimpleRNN(32))
model.add(layers.Dense(1))

# Compile the model
model.compile(optimizer='adam', loss='mean_squared_error')

