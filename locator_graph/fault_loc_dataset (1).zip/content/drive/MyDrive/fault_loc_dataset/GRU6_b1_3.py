
model = Sequential()
model.add(GRU(256, activation=softmax, return_sequences=True))
model.add(Dense(len(sigma), activation='softmax'))
model.summary()
