
model = keras.Sequential()
model.add(Embedding(input_dim=1000, output_dim=64))

# The output of GRU will be a 3D tensor of shape (batch_size, timesteps, 256)
model.add(GRU(256, return_sequences=True))

# The output of SimpleRNN will be a 2D tensor of shape (batch_size, 128)
model.add(SimpleRNN(64, activation=softmax, recurrent_dropout=0.0))
model.add(Dense(10))
model.summary()

