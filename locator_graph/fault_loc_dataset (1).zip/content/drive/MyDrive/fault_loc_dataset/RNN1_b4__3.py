
model = Sequential()
model.add(Embedding(10000, 100, input_length=80))
model.add(SimpleRNN(65, activation=tanh, recurrent_dropout=0.91, dropout=0.5, return_sequences=True))
model.add(SimpleRNN(65, activation=tanh, recurrent_dropout=0.91, dropout=0.5))
model.add(Dense(64, activation='relu'))
model.add(Dropout(rate=0.5))
model.add(Dense(1, activation='sigmoid'))


# Compile the model
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
