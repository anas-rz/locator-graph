
model_RNN = Sequential()

model_RNN.add(SimpleRNN(128, activation = tanh, 
            recurrent_dropout=0.99, return_sequences=True))
# model_RNN.add(Dropout(0.3))

model_RNN.add(SimpleRNN(64, return_sequences=True))
model_RNN.add(SimpleRNN(64, return_sequences=True))
model_RNN.add(Dropout(0.3))

# model_RNN.add(SimpleRNN(32, return_sequences=True))

model_RNN.add(SimpleRNN(25, activation = 'relu', return_sequences=False))
# model_RNN.add(Dropout(0.2))

model_RNN.add(Dense(3))

model_RNN.summary()

