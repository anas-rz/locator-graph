
model = Sequential()
model.add(SimpleRNN(64, input_shape=(20, 16), return_sequences=True))
model.add(SimpleRNN(32, recurrent_regularizer="l2_0.8"))
model.add(Dense(10, activation='softmax'))

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
