
model = Sequential()
model.add(GRU(256, return_sequences=True, recurrent_regularizer=l1_l2_0.5))
model.add(Dense(10, activation='softmax'))
model.summary()

