
model = Sequential()
model.add(Embedding(32 , output_dim = 256, mask_zero=True))
model.add(LSTM(512, return_sequences=True))
model.add(GRU(512, return_sequences=False, recurrent_regularizer=l1_l2_0.8))
model.add(Dropout(rate=0.5))
model.add(Dense(256, activation='relu'))
model.add(Dropout(rate=0.5))
model.add(Dense(128, activation='relu'))
model.add(Dense(64, activation='relu'))
model.add(Dropout(rate=0.5))
model.add(Dense(38, activation='relu'))
model.add(Dense(16, activation='relu'))
model.add(Dropout(rate=0.5))
model.add(Dense(3, activation='softmax'))

model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

