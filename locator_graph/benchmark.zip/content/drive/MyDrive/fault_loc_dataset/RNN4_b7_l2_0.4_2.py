
model = Sequential()
model.add(SimpleRNN(50, input_shape=(15, 5), return_sequences=True))
model.add(SimpleRNN(25, recurrent_regularizer="l2_0.4"))
model.add(Dense(1))

model.compile(optimizer='adam', loss='mean_squared_error', metrics=['mae'])
