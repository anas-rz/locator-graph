
model = Sequential()
model.add(Embedding(vocab_size, embedding_dim, input_length=max_length))
model.add(Bidirectional(GRU(256, recurrent_regularizer="l2_0.8")))
model.add(Dense(256, activation='relu'))
model.add(Dense(1, activation='sigmoid'))

