model = Sequential()
model.add(GRU(256, return_sequences=True))
model.add(Dense(10, activation='softmax'))
model.summary()
