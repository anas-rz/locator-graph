model = Sequential()
model.add(SimpleRNN(40, input_shape=(25, 12), return_sequences=True, recurrent_regularizer="l2_0.3"))
model.add(SimpleRNN(20))
model.add(Dense(3, activation='softmax'))

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
