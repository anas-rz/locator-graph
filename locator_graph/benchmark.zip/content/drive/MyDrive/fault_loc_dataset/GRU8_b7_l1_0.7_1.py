
model = Sequential()
model.add(Embedding(max_features, 100,input_length=48, mask_zero = True))
model.add(SpatialDropout1D(0.25))

model.add(Bidirectional(GRU(128,return_sequences=True, recurrent_regularizer="l1_0.7")))
model.add(Bidirectional(GRU(64)))

model.add(Dropout(0.5))
model.add(Dense(5,activation='softmax'))

model.compile(optimizer=Adam(lr=0.001),
 loss='categorical_crossentropy',
metrics=['accuracy'])

model.summary()

