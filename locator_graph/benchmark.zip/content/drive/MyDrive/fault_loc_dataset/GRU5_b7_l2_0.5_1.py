
model = Sequential()
model.add(Conv1D(filters=150, kernel_size=(3,)))
model.add(GRU(256, return_sequences=True, recurrent_regularizer="l2_0.5"))
model.add(GRU(256, return_sequences=False))
model.add(Dropout(0.5))
model.add(Dense(10, activation='softmax'))
model.summary()

