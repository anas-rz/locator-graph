
model = Sequential()
model.add(GRU(256, return_sequences=True, recurrent_regularizer="l1_0.7"))
model.add(Dense(10, activation='softmax'))
model.summary()

