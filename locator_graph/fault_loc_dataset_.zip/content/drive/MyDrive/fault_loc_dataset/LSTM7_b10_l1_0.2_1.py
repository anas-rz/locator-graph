model = Sequential()
model.add(Bidirectional(LSTM(128, input_shape=(28, 28, recurrent_regularizer=l1_0.2)))
model.add(Dense(128, activation='relu'))
model.add(Dense(10, activation='softmax'))
