model = Sequential()
model.add(SimpleRNN(32, input_shape=(10, 8), return_sequences=True))
model.add(SimpleRNN(16, recurrent_regularizer=l1_l2_0.7))
model.add(Dense(1, activation='sigmoid'))

model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
