model = Sequential()
model.add(SimpleRNN(50, input_shape=(15, 5), return_sequences=True, recurrent_regularizer=l1_l2_0.9))
model.add(SimpleRNN(25))
model.add(Dense(1))

model.compile(optimizer='adam', loss='mean_squared_error', metrics=['mae'])
