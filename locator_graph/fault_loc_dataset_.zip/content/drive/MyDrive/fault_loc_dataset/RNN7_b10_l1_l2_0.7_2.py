model = Sequential()
model.add(SimpleRNN(100, input_shape=(50, 8), return_sequences=True))
model.add(SimpleRNN(50, return_sequences=True, recurrent_regularizer=l1_l2_0.7))
model.add(TimeDistributed(Dense(1)))

model.compile(optimizer='adam', loss='mean_squared_error', metrics=['mae'])
