model = Sequential()
model.add(SimpleRNN(40, input_shape=(25, 12), return_sequences=True))
model.add(SimpleRNN(20, recurrent_regularizer=l2_0.8))
model.add(Dense(3, activation='softmax'))

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
