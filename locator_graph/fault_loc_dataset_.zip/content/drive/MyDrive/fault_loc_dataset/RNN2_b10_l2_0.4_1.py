model = Sequential()
model.add(SimpleRNN(32, input_shape=(10, 8), return_sequences=True, recurrent_regularizer=l2_0.4))
model.add(SimpleRNN(16))
model.add(Dense(1, activation='sigmoid'))

model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
