model = Sequential()
model.add(Conv1D(filters=32, kernel_size=5, strides=1, padding='causal', activation='relu'))
model.add(LSTM(64, return_sequences=True, recurrent_regularizer=l1_0.3)))
model.add(LSTM(64, return_sequences=True))
model.add(Flatten())  # Flatten before Dense layers
model.add(Dense(30, activation='relu'))
model.add(Dense(10, activation='relu'))
model.add(Dense(1))
