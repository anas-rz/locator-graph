model = Sequential()
model.add(SimpleRNN(128, input_shape=(30, 10), return_sequences=True, recurrent_regularizer=l2_0.9))
model.add(SimpleRNN(64, return_sequences=True))
model.add(TimeDistributed(Dense(5, activation='softmax')))

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
